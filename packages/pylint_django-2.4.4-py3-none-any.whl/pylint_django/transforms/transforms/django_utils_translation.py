def gettext_lazy(_):
    return ''


ugettext_lazy = gettext_lazy  # pylint:disable=invalid-name
