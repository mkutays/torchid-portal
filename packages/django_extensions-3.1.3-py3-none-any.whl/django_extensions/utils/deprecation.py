# -*- coding: utf-8 -*-

class MarkedForDeprecationWarning(DeprecationWarning):
    pass


class RemovedInNextVersionWarning(DeprecationWarning):
    pass
